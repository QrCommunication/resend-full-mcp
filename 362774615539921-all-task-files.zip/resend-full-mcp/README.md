# Resend Full MCP Server

A comprehensive **Model Context Protocol (MCP)** server that provides complete access to the **Resend API**. This MCP implementation covers all 12 modules and 70+ tools available in the Resend email platform.

## 🚀 Features

This MCP server provides full coverage of the Resend API with the following modules:

### 📧 **Emails** (8 tools)
- `send_email` - Send single emails with HTML/text, attachments, templates
- `send_batch_emails` - Send up to 100 emails at once
- `list_emails` - Retrieve sent emails with pagination
- `get_email` - Get details of a specific email
- `update_email` - Update scheduled emails
- `cancel_email` - Cancel scheduled emails
- `list_email_attachments` - List attachments for sent emails
- `get_email_attachment` - Retrieve specific attachment

### 📨 **Receiving Emails** (4 tools)
- `list_received_emails` - List received emails
- `get_received_email` - Get received email details
- `list_received_email_attachments` - List attachments from received emails
- `get_received_email_attachment` - Get specific received email attachment

### 🌐 **Domains** (6 tools)
- `create_domain` - Add new domain
- `list_domains` - List all domains
- `get_domain` - Get domain details
- `update_domain` - Update domain settings
- `delete_domain` - Remove domain
- `verify_domain` - Verify domain DNS records

### 🔑 **API Keys** (3 tools)
- `create_api_key` - Create new API key
- `list_api_keys` - List all API keys
- `delete_api_key` - Revoke API key

### 👥 **Audiences** (4 tools)
- `create_audience` - Create new audience/mailing list
- `list_audiences` - List all audiences
- `get_audience` - Get audience details
- `delete_audience` - Delete audience

### 📇 **Contacts** (13 tools)
- `create_contact` - Add contact to audience
- `list_contacts` - List all contacts in audience
- `get_contact_by_email` - Get contact by email
- `get_contact_by_id` - Get contact by ID
- `update_contact_by_email` - Update contact by email
- `update_contact_by_id` - Update contact by ID
- `delete_contact_by_email` - Delete contact by email
- `delete_contact_by_id` - Delete contact by ID
- `add_contact_to_segment` - Add contact to segment
- `remove_contact_from_segment` - Remove contact from segment
- `list_contact_segments` - List contact's segments
- `get_contact_topics` - Get contact topic subscriptions
- `update_contact_topics` - Update contact topic subscriptions

### 📝 **Templates** (7 tools)
- `create_template` - Create email template
- `list_templates` - List all templates
- `get_template` - Get template details
- `update_template` - Update template
- `delete_template` - Delete template
- `publish_template` - Publish draft template
- `duplicate_template` - Duplicate existing template

### 📢 **Broadcasts** (6 tools)
- `create_broadcast` - Create broadcast campaign
- `list_broadcasts` - List all broadcasts
- `get_broadcast` - Get broadcast details
- `update_broadcast` - Update draft broadcast
- `delete_broadcast` - Delete draft broadcast
- `send_broadcast` - Send or schedule broadcast

### 🪝 **Webhooks** (5 tools)
- `create_webhook` - Create webhook endpoint
- `list_webhooks` - List all webhooks
- `get_webhook` - Get webhook details
- `update_webhook` - Update webhook configuration
- `delete_webhook` - Delete webhook

### 🎯 **Segments** (4 tools)
- `create_segment` - Create audience segment
- `list_segments` - List all segments
- `get_segment` - Get segment details
- `delete_segment` - Delete segment

### 🏷️ **Topics** (5 tools)
- `create_topic` - Create subscription topic
- `list_topics` - List all topics
- `get_topic` - Get topic details
- `update_topic` - Update topic
- `delete_topic` - Delete topic

### 🔧 **Contact Properties** (5 tools)
- `create_contact_property` - Create custom contact property
- `list_contact_properties` - List all contact properties
- `get_contact_property` - Get property details
- `update_contact_property` - Update property
- `delete_contact_property` - Delete property

## 📋 Prerequisites

- **Node.js** 18+ (recommended: v20 or later)
- **TypeScript** 5+
- **Resend Account** with API key ([Get one here](https://resend.com))

## 🛠️ Installation

### 1. Clone the repository

```bash
git clone https://github.com/QrCommunication/resend-full-mcp.git
cd resend-full-mcp
```

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` and add your Resend API key:

```env
RESEND_API_KEY=re_your_api_key_here
```

> **Security Note**: Never commit your `.env` file to version control. It's already included in `.gitignore`.

### 4. Build the project

```bash
npm run build
```

## 🚀 Usage

### Start the server

```bash
npm start
```

### Development mode (with auto-reload)

```bash
npm run dev
```

## 📖 Tool Examples

### Sending an Email

```json
{
  "method": "tools/call",
  "params": {
    "name": "send_email",
    "arguments": {
      "from": "Your Name <onboarding@yourdomain.com>",
      "to": ["recipient@example.com"],
      "subject": "Hello from Resend MCP",
      "html": "<p>This is a <strong>test email</strong> from the Resend MCP server!</p>",
      "text": "This is a test email from the Resend MCP server!"
    }
  }
}
```

### Sending Batch Emails

```json
{
  "method": "tools/call",
  "params": {
    "name": "send_batch_emails",
    "arguments": {
      "emails": [
        {
          "from": "team@yourdomain.com",
          "to": ["user1@example.com"],
          "subject": "Welcome!",
          "html": "<p>Welcome to our service!</p>"
        },
        {
          "from": "team@yourdomain.com",
          "to": ["user2@example.com"],
          "subject": "Welcome!",
          "html": "<p>Welcome to our service!</p>"
        }
      ]
    }
  }
}
```

### Creating an Audience

```json
{
  "method": "tools/call",
  "params": {
    "name": "create_audience",
    "arguments": {
      "name": "Newsletter Subscribers"
    }
  }
}
```

### Adding a Contact

```json
{
  "method": "tools/call",
  "params": {
    "name": "create_contact",
    "arguments": {
      "audience_id": "your_audience_id",
      "email": "subscriber@example.com",
      "first_name": "John",
      "last_name": "Doe"
    }
  }
}
```

### Creating a Broadcast

```json
{
  "method": "tools/call",
  "params": {
    "name": "create_broadcast",
    "arguments": {
      "name": "Weekly Newsletter",
      "segment_id": "your_segment_id",
      "from": "newsletter@yourdomain.com",
      "subject": "This Week's Updates",
      "html": "<h1>Weekly Updates</h1><p>Here's what happened this week...</p>",
      "send": false
    }
  }
}
```

### Setting Up a Webhook

```json
{
  "method": "tools/call",
  "params": {
    "name": "create_webhook",
    "arguments": {
      "endpoint": "https://yourapp.com/webhooks/resend",
      "events": ["email.sent", "email.delivered", "email.bounced"]
    }
  }
}
```

## 🔍 Listing All Available Tools

```json
{
  "method": "tools/list",
  "params": {}
}
```

This will return all 70+ tools with their descriptions and input schemas.

## 🏗️ Project Structure

```
resend-full-mcp/
├── src/
│   └── index.ts          # Main MCP server implementation
├── dist/                 # Compiled JavaScript (generated)
├── package.json          # Project dependencies and scripts
├── tsconfig.json         # TypeScript configuration
├── .env                  # Environment variables (not in git)
├── .env.example          # Environment template
├── .gitignore            # Git ignore rules
└── README.md             # This file
```

## 🔧 Configuration

### TypeScript Configuration

The project uses strict TypeScript settings for maximum type safety:

```json
{
  "compilerOptions": {
    "target": "es2020",
    "module": "commonjs",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  }
}
```

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `RESEND_API_KEY` | ✅ Yes | Your Resend API key from the dashboard |

## 📚 API Documentation

For detailed API documentation, visit:
- [Resend API Documentation](https://resend.com/docs/api-reference)
- [Resend Dashboard](https://resend.com/dashboard)

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/amazing-feature`
3. **Commit your changes**: `git commit -m 'Add amazing feature'`
4. **Push to the branch**: `git push origin feature/amazing-feature`
5. **Open a Pull Request**

### Development Guidelines

- Write clear, descriptive commit messages
- Add tests for new features
- Update documentation as needed
- Follow TypeScript best practices
- Ensure all tests pass before submitting PR

## 🐛 Troubleshooting

### Error: "RESEND_API_KEY environment variable is not set"

**Solution**: Create a `.env` file with your Resend API key:
```bash
echo "RESEND_API_KEY=re_your_key_here" > .env
```

### Error: "Tool execution failed"

**Possible causes**:
- Invalid API key
- Missing required parameters
- API rate limits exceeded
- Network connectivity issues

**Solution**: Check the error message details and verify your API key and parameters.

### Error: "Unknown tool"

**Solution**: Verify the tool name using the `tools/list` method to see all available tools.

## 📄 License

This project is licensed under the MIT License - see below for details:

```
MIT License

Copyright (c) 2024 QrCommunication

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 🙏 Acknowledgments

- [Resend](https://resend.com) for providing an excellent email API
- The Model Context Protocol community
- All contributors to this project

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/QrCommunication/resend-full-mcp/issues)
- **Discussions**: [GitHub Discussions](https://github.com/QrCommunication/resend-full-mcp/discussions)
- **Resend Support**: [Resend Documentation](https://resend.com/docs)

## 🔗 Links

- [Resend Website](https://resend.com)
- [Resend API Documentation](https://resend.com/docs/api-reference)
- [Model Context Protocol Specification](https://modelcontextprotocol.io)
- [GitHub Repository](https://github.com/QrCommunication/resend-full-mcp)

---

**Made with ❤️ for developers who value great email delivery**
